package com.example.autoswiperight

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.autoswiperight.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val prefs by lazy {
        getSharedPreferences(AutoSwipeService.PREFS_NAME, Context.MODE_PRIVATE)
    }

    private val stateListener: () -> Unit = { updateStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Interval: progress 0..195 -> 0.5..20.0 s (0.1 s steps)
        // Duration: progress 0..190 -> 100..2000 ms (10 ms steps)
        val intervalMs = prefs.getInt(
            AutoSwipeService.KEY_INTERVAL_MS, AutoSwipeService.DEFAULT_INTERVAL_MS
        ).coerceIn(AutoSwipeService.MIN_INTERVAL_MS, AutoSwipeService.MAX_INTERVAL_MS)
        val durationMs = prefs.getInt(
            AutoSwipeService.KEY_DURATION_MS, AutoSwipeService.DEFAULT_DURATION_MS
        ).coerceIn(AutoSwipeService.MIN_DURATION_MS, AutoSwipeService.MAX_DURATION_MS)

        binding.intervalSeek.progress = (intervalMs - 500) / 100
        binding.durationSeek.progress = (durationMs - 100) / 10
        updateIntervalLabel()
        updateDurationLabel()

        binding.intervalSeek.setOnSeekBarChangeListener(object : SimpleSeekListener() {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                updateIntervalLabel()
                if (fromUser) prefs.edit().putInt(AutoSwipeService.KEY_INTERVAL_MS, currentIntervalMs()).apply()
            }
        })
        binding.durationSeek.setOnSeekBarChangeListener(object : SimpleSeekListener() {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                updateDurationLabel()
                if (fromUser) prefs.edit().putInt(AutoSwipeService.KEY_DURATION_MS, currentDurationMs()).apply()
            }
        })

        binding.accessibilityButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        binding.overlayButton.setOnClickListener {
            val service = AutoSwipeService.instance
            when {
                service == null ->
                    Toast.makeText(this, R.string.enable_first, Toast.LENGTH_LONG).show()
                service.isOverlayVisible() -> service.hideOverlay()
                else -> service.showOverlay()
            }
            updateStatus()
        }
        binding.stopButton.setOnClickListener {
            AutoSwipeService.instance?.stopSwiping()
            updateStatus()
        }
    }

    override fun onStart() {
        super.onStart()
        AutoSwipeService.onStateChanged = stateListener
        updateStatus()
    }

    override fun onStop() {
        AutoSwipeService.onStateChanged = null
        super.onStop()
    }

    private fun currentIntervalMs() = 500 + binding.intervalSeek.progress * 100
    private fun currentDurationMs() = 100 + binding.durationSeek.progress * 10

    private fun updateIntervalLabel() {
        binding.intervalLabel.text = getString(R.string.interval_label, currentIntervalMs() / 1000f)
    }

    private fun updateDurationLabel() {
        binding.durationLabel.text = getString(R.string.duration_label, currentDurationMs())
    }

    private fun updateStatus() {
        val service = AutoSwipeService.instance
        val running = service?.isRunning() == true
        binding.statusText.setText(if (running) R.string.status_running else R.string.status_stopped)
        binding.statusText.setTextColor(
            ContextCompat.getColor(this, if (running) R.color.status_running else R.color.status_stopped)
        )
        binding.serviceText.setText(
            if (service != null) R.string.service_enabled else R.string.service_disabled
        )
        binding.overlayButton.setText(
            if (service?.isOverlayVisible() == true) R.string.overlay_hide else R.string.overlay_show
        )
    }

    private abstract class SimpleSeekListener : SeekBar.OnSeekBarChangeListener {
        override fun onStartTrackingTouch(seekBar: SeekBar) {}
        override fun onStopTrackingTouch(seekBar: SeekBar) {}
    }
}
