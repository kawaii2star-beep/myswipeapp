package com.example.autoswiperight

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

/**
 * Performs repeated left-to-right swipes while running, controlled by a small floating button.
 * It does nothing else: it does not read screen content and does not touch any other element.
 * It only looks at which app is in front (package name) so it can stop when you leave that app.
 */
class AutoSwipeService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val swipeRunnable = Runnable { performSwipe() }

    private var running = false

    // Incremented on every stop so late callbacks from an old gesture are ignored.
    private var session = 0

    private var consecutiveCancels = 0

    // Last app seen in front (ignoring our own overlay and SystemUI), and the app swiping is locked to.
    private var currentPackage: String? = null
    private var targetPackage: String? = null

    private var overlayView: View? = null
    private var overlayButton: TextView? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    private val prefs: SharedPreferences by lazy {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    private val windowManager: WindowManager
        get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        notifyStateChanged()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        // Ignore windows of our own overlay; our settings screen counts as a real app change.
        val isOwnOverlay = pkg == packageName &&
            event.className?.toString() != MainActivity::class.java.name
        if (isOwnOverlay) return

        if (running) {
            // Any switch away from the locked app (home, recents, another app, shade) stops swiping.
            if (pkg != targetPackage) stopSwiping()
            return
        }
        if (pkg != SYSTEM_UI_PACKAGE) currentPackage = pkg
    }

    override fun onInterrupt() {
        stopSwiping()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopSwiping()
        removeOverlayView()
        if (instance === this) instance = null
        notifyStateChanged()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stopSwiping()
        removeOverlayView()
        if (instance === this) instance = null
        notifyStateChanged()
        super.onDestroy()
    }

    fun isRunning(): Boolean = running

    fun isOverlayVisible(): Boolean = overlayView != null

    private fun startSwiping() {
        if (running) return
        running = true
        consecutiveCancels = 0
        notifyStateChanged()
        handler.postDelayed(swipeRunnable, FIRST_SWIPE_DELAY_MS)
    }

    fun stopSwiping() {
        val wasRunning = running
        running = false
        targetPackage = null
        session++
        handler.removeCallbacksAndMessages(null)
        if (wasRunning) notifyStateChanged()
    }

    private fun performSwipe() {
        if (!running) return

        val (width, height) = screenSize()
        val duration = prefs.getInt(KEY_DURATION_MS, DEFAULT_DURATION_MS)
            .coerceIn(MIN_DURATION_MS, MAX_DURATION_MS).toLong()

        val path = Path().apply {
            moveTo(width * START_X_FRACTION, height * Y_FRACTION)
            lineTo(width * END_X_FRACTION, height * Y_FRACTION)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, duration))
            .build()

        val mySession = session
        val callback = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (!running || mySession != session) return
                consecutiveCancels = 0
                scheduleNext()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (!running || mySession != session) return
                consecutiveCancels++
                if (consecutiveCancels >= MAX_CONSECUTIVE_CANCELS) stopSwiping() else scheduleNext()
            }
        }

        val dispatched = dispatchGesture(gesture, callback, handler)
        if (!dispatched) stopSwiping()
    }

    private fun scheduleNext() {
        val interval = prefs.getInt(KEY_INTERVAL_MS, DEFAULT_INTERVAL_MS)
            .coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS).toLong()
        handler.removeCallbacks(swipeRunnable)
        handler.postDelayed(swipeRunnable, interval)
    }

    // ---------------------------------------------------------------- overlay

    @SuppressLint("ClickableViewAccessibility")
    fun showOverlay() {
        if (overlayView != null) return
        val density = resources.displayMetrics.density
        val dp = { v: Int -> (v * density).toInt() }

        val button = TextView(this).apply {
            text = getString(R.string.start)
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(COLOR_START)
            }
        }
        val close = TextView(this).apply {
            text = "\u2715"
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { hideOverlay() }
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.parseColor("#E6202020"))
            }
            addView(button)
            addView(close)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenSize().first - dp(170)).coerceAtLeast(0)
            y = dp(120)
        }

        // Tap = toggle START/STOP, drag = move the overlay.
        button.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var dragged = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = e.rawX
                        touchY = e.rawY
                        dragged = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - touchX
                        val dy = e.rawY - touchY
                        if (!dragged && hypot(dx, dy) > dp(8)) dragged = true
                        if (dragged) {
                            params.x = startX + dx.toInt()
                            params.y = startY + dy.toInt()
                            try {
                                windowManager.updateViewLayout(container, params)
                            } catch (_: Exception) {
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!dragged) toggleFromOverlay()
                        return true
                    }
                }
                return false
            }
        })

        try {
            windowManager.addView(container, params)
        } catch (_: Exception) {
            return
        }
        overlayView = container
        overlayButton = button
        overlayParams = params
        notifyStateChanged()
    }

    /** Stops swiping and removes the floating button. */
    fun hideOverlay() {
        stopSwiping()
        removeOverlayView()
        notifyStateChanged()
    }

    private fun removeOverlayView() {
        val view = overlayView ?: return
        try {
            windowManager.removeView(view)
        } catch (_: Exception) {
        }
        overlayView = null
        overlayButton = null
        overlayParams = null
    }

    private fun toggleFromOverlay() {
        if (running) {
            stopSwiping()
            return
        }
        val pkg = currentPackage
        if (pkg == null || pkg == packageName || pkg == homePackage()) {
            Toast.makeText(this, R.string.open_app_first, Toast.LENGTH_LONG).show()
            return
        }
        targetPackage = pkg
        startSwiping()
    }

    private fun updateOverlayAppearance() {
        val button = overlayButton ?: return
        button.text = getString(if (running) R.string.stop else R.string.start)
        (button.background as? GradientDrawable)?.setColor(if (running) COLOR_STOP else COLOR_START)
    }

    private fun homePackage(): String? = try {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
    } catch (_: Exception) {
        null
    }

    // ---------------------------------------------------------------- helpers

    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun notifyStateChanged() {
        updateOverlayAppearance()
        onStateChanged?.invoke()
    }

    companion object {
        const val PREFS_NAME = "auto_swipe_prefs"
        const val KEY_INTERVAL_MS = "interval_ms"
        const val KEY_DURATION_MS = "duration_ms"

        const val MIN_INTERVAL_MS = 500
        const val MAX_INTERVAL_MS = 20_000
        const val DEFAULT_INTERVAL_MS = 3_000

        const val MIN_DURATION_MS = 100
        const val MAX_DURATION_MS = 2_000
        const val DEFAULT_DURATION_MS = 350

        private const val START_X_FRACTION = 0.45f
        private const val END_X_FRACTION = 0.92f
        private const val Y_FRACTION = 0.50f

        // Short pause so the tap on the overlay is finished before the first swipe.
        private const val FIRST_SWIPE_DELAY_MS = 300L
        private const val MAX_CONSECUTIVE_CANCELS = 3
        private const val SYSTEM_UI_PACKAGE = "com.android.systemui"

        private val COLOR_START = Color.parseColor("#2E7D32")
        private val COLOR_STOP = Color.parseColor("#C62828")

        /** The connected service, or null when it is not enabled/connected. */
        @Volatile
        var instance: AutoSwipeService? = null
            private set

        /** Set by the UI while visible (and cleared when hidden) to avoid leaking the Activity. */
        @Volatile
        var onStateChanged: (() -> Unit)? = null
    }
}
